# Classical LSTM vs. a Modern LLM for Abstractive News Summarization

**GitHub:** [INSERT URL]  
**Demo video:** [INSERT URL]

## 1. Problem and Dataset

We formulate abstractive summarization as a sequence-to-sequence task. The input is
a news article and the desired output is a short natural-language summary. We use
CNN/DailyMail 3.0.0. The official dataset partitions are preserved before model
development; we subsample [INSERT] training, [INSERT] validation, and [INSERT] test
examples with random seed 42. Vocabulary construction uses only the training sample.

The Hugging Face repository currently carries an Apache-2.0 license tag, while its
dataset card specifically identifies CNN/DailyMail version 1.0.0 as released under
Apache-2.0. The underlying articles were authored by CNN and Daily Mail journalists.
We therefore cite the dataset and original papers and treat the article text as
copyrighted source content used for academic research.

Articles are truncated to 400 word-level tokens and reference summaries to 78 content
tokens before special tokens. This makes training feasible for a classical recurrent
model. The same 400-token source representation is passed to the LLM in the main
comparison.

## 2. System Design and Experimental Settings

### 2.1 LSTM with attention

Our model contains a word embedding layer, a bidirectional LSTM encoder, Bahdanau
additive attention, a unidirectional LSTM decoder, and a vocabulary projection layer.
The encoder produces contextual states for every source position. At each decoding
step, attention computes a weighted combination of those states based on the current
decoder hidden state. Teacher forcing is used during training, padding positions are
masked, gradients are clipped, and early stopping is based on validation loss.

Hyperparameters: embedding size [INSERT], encoder hidden size [INSERT], decoder hidden
size [INSERT], batch size [INSERT], learning rate [INSERT], teacher-forcing ratio
[INSERT], dropout [INSERT], maximum source length [INSERT], maximum target length
[INSERT]. The model contains **[INSERT] trainable parameters** and trained for
**[INSERT] minutes/hours** on **[INSERT HARDWARE]**.

### 2.2 Ablation

We train a no-attention ablation with the same preprocessing and major hyperparameters.
Instead of recomputing an attention distribution at every decoder step, the decoder
receives one fixed mean-pooled encoder context vector. This tests whether dynamic
attention improves generation quality.

### 2.3 LLM baseline

We evaluate the same held-out test examples using [INSERT MODEL SNAPSHOT]. We test
zero-shot and 4-shot prompting under two instruction variants: **concise** and
**faithful**. Few-shot examples are selected only from the training split. The exact
prompts and demonstrations are included in Appendix A. Total API usage was [INSERT]
input tokens and [INSERT] output tokens, corresponding to an estimated cost of
**US$[INSERT]** using the provider's prices on [INSERT DATE].

## 3. Results

We use ROUGE-1, ROUGE-2, and ROUGE-L F1 because CNN/DailyMail supplies reference
highlights and ROUGE is a standard overlap-based metric for summarization.

| System | ROUGE-1 | ROUGE-2 | ROUGE-L | Runtime / Cost |
|---|---:|---:|---:|---:|
| LSTM + attention | [ ] | [ ] | [ ] | [ ] |
| LSTM without attention | [ ] | [ ] | [ ] | [ ] |
| LLM zero-shot, concise | [ ] | [ ] | [ ] | [ ] |
| LLM zero-shot, faithful | [ ] | [ ] | [ ] | [ ] |
| LLM 4-shot, concise | [ ] | [ ] | [ ] | [ ] |
| LLM 4-shot, faithful | [ ] | [ ] | [ ] | [ ] |

The LSTM–LLM ROUGE-L gap is [INSERT] points for [INSERT BEST FAIR COMPARISON].
[DESCRIBE WHETHER THE GAP CHANGES FOR SHORT/MEDIUM/LONG INPUTS USING MEASURED DATA.]

## 4. Qualitative Error Analysis

Present at least 10 test cases with the article/source, reference, LSTM output, and LLM
output. Choose cases that represent different observed behaviors rather than only good
examples.

Useful categories to verify against the outputs include missing key information,
repetition, hallucinated details, incorrect entities/numbers, excessive copying,
rare-word/OOV failures, poor fluency, and overly long summaries.

| # | Source / key facts | Reference | LSTM + attention | LLM | Error category |
|---|---|---|---|---|---|
| 1 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 2 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 3 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 4 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 5 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 6 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 7 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 8 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 9 | [ ] | [ ] | [ ] | [ ] | [ ] |
| 10 | [ ] | [ ] | [ ] | [ ] | [ ] |

## 5. Discussion, Limitations, and Trade-offs

The performance gap can be explained using course concepts. The LSTM is trained from
scratch on only [INSERT] examples with a limited word vocabulary. Even with attention,
its recurrent computation is sequential and its learned representations are restricted
to this task-specific corpus. The LLM benefits from vastly greater model capacity,
large-scale pretraining, transfer learning, and transformer self-attention.

The comparison is unfair in both directions. The LLM has seen vastly more text and may
have encountered CNN/DailyMail-like material during pretraining, creating possible data
contamination. Conversely, the LSTM is small, specialized, locally deployable, and has
predictable inference behavior without per-request API charges. A fairer middle point
would be a small pretrained transformer fine-tuned on the same training examples.

ROUGE is also limited because lexical overlap does not guarantee factual correctness or
semantic quality. A paraphrase may receive a low score despite being valid, while a
summary with strong word overlap can still distort a fact. The dataset contains biases
of its news sources and time period. Truncating articles to 400 tokens can remove facts
that occur later in the article. Environmental and compute costs also differ: training
the LSTM has an up-front cost, while hosted LLM inference consumes provider-side compute
for every request.

Under privacy, offline deployment, predictable latency, low per-request cost at high
volume, or strict domain-control constraints, a small specialized model may still be
useful even if its generation quality is lower. The measured results in this study
should determine how large that quality trade-off actually is.

# References

Hermann, K. M., et al. (2015). *Teaching Machines to Read and Comprehend*. NeurIPS.

See, A., Liu, P. J., & Manning, C. D. (2017). *Get To The Point: Summarization with
Pointer-Generator Networks*. ACL.

Bahdanau, D., Cho, K., & Bengio, Y. (2015). *Neural Machine Translation by Jointly
Learning to Align and Translate*. ICLR.

Lin, C.-Y. (2004). *ROUGE: A Package for Automatic Evaluation of Summaries*.

# Appendix A — Exact LLM Prompts

**Concise prompt:**

> Summarize the news article in 2-3 concise sentences. Keep only the most important
> information. Do not add facts that are not supported by the article. Output only
> the summary.

**Faithful prompt:**

> Write a faithful abstractive summary of the news article. Preserve the key people,
> events, and outcome, remove secondary details, and do not speculate. Keep the summary
> under 80 tokens. Output only the summary.

For the 4-shot condition, insert the exact four training examples saved by
`run_llm_baseline.py` in its metadata file.

# Appendix B — Contribution Statement

[INSERT each team member and concrete contribution.]

# Appendix C — AI-Use Disclosure

[Describe exactly where generative AI tools were used, following the course/instructor
policy. Do not claim work was completed manually if AI assistance was used.]
