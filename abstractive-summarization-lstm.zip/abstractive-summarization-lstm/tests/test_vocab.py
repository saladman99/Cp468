from vocab import Vocab, detokenize, tokenize


def test_tokenize_and_decode():
    tokens = tokenize("The cat isn't sleeping.")
    vocab = Vocab.build([tokens], max_size=100, min_freq=1)
    ids = vocab.encode(tokens, add_sos_eos=True)
    decoded = vocab.decode(ids)
    assert decoded == tokens
    assert "cat" in detokenize(decoded)
