import torch

from model import Seq2SeqSummarizer


def test_forward_shapes():
    model = Seq2SeqSummarizer(
        src_vocab_size=50,
        tgt_vocab_size=40,
        embed_dim=16,
        encoder_hidden_dim=12,
        decoder_hidden_dim=24,
        src_pad_id=0,
        tgt_pad_id=0,
        dropout=0.0,
        use_attention=True,
    )
    src = torch.tensor([[4, 5, 6, 0], [7, 8, 0, 0]])
    src_lengths = torch.tensor([3, 2])
    tgt = torch.tensor([[2, 9, 10, 3], [2, 11, 3, 0]])
    logits = model(src, src_lengths, tgt, teacher_forcing_ratio=1.0)
    assert logits.shape == (2, 3, 40)


def test_greedy_decode_runs_without_attention():
    model = Seq2SeqSummarizer(
        src_vocab_size=30,
        tgt_vocab_size=25,
        embed_dim=8,
        encoder_hidden_dim=6,
        decoder_hidden_dim=12,
        src_pad_id=0,
        tgt_pad_id=0,
        dropout=0.0,
        use_attention=False,
    )
    src = torch.tensor([[4, 5, 6], [7, 8, 0]])
    lengths = torch.tensor([3, 2])
    out = model.greedy_decode(src, lengths, sos_id=2, eos_id=3, max_len=5)
    assert out.shape[0] == 2
    assert out.shape[1] <= 5
